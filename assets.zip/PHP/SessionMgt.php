<?php
session_start();
if(empty($_SESSION['SID']))
    {
        //echo "<script>location.href='./index.php'</script>";
    }
?>