<?php
    $hostname="sql213.epizy.com";
    $username="epiz_32475954";
    $password='vo6nia5fWL';
    $dbname="epiz_32475954_ramdev_tred";
    $con=mysqli_connect("localhost","root",'',"ramdev_tred") or die("Server Error");
    //$con=mysqli_connect($hostname,$username,$password,$dbname) or die("Server Error");
?>